package Selenium.SeleniumExcercies;

import java.util.Map;

//import org.json.simple.JSONObject;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class MainProgram {

	public static void main(String[] args) throws JSONException {
		System.out.println("This is Main Method");
		ExcerciseGetJSON();
		ExcerciseJSONPUT();
		ExcerciseJSONPOST();
		ExcerciseJSONDELETE();
		
		
		// The following method only you asked to do
		ExcerciseValidatePostJSON();

	}
	
	public static void ExcerciseGetJSON() throws JSONException {

		Response Resp=RestAssured.get("http://localhost:3000/employees123/11");		
		int code=Resp.getStatusCode();	
		System.out.println("Status code :"+code);		
		String Data=Resp.asString();		
		System.out.println("Data is :"+Data);
		
		JSONObject A = new JSONObject(Data);
		A.get("first_name");
		System.out.println(A.get("first_name"));
		
		

	}
	
	public static void ExcerciseJSONPUT() throws JSONException {

		RequestSpecification request = RestAssured.given(); // Request specification means sending the request in this format

		request.header("Content-Type", "application/json"); // Add header

		JSONObject JSON = new JSONObject(); // Create JSON object

		
		JSON.put("first_name", "Dummy3First");
		JSON.put("last_name", "Dummy3Last");
		JSON.put( "email", "Dummy3@martway.com");
			
		request.body(JSON.toString()); // Create Body

		Response resp = request.put("http://localhost:3000/employees123/3"); // PUT -  to update
		

		int code = resp.getStatusCode();

		System.out.println("The Code is :" + code);

	}
	
	public static void ExcerciseJSONPOST() throws JSONException {

		RequestSpecification request = RestAssured.given(); // Request specification means sending the request in this format

		request.header("Content-Type", "application/json"); // Add header

		JSONObject JSON = new JSONObject(); // Create JSON object	
		JSON.put("id", 11);
		JSON.put("first_name", "DummyFirst11");
		JSON.put("last_name", "DummyLast11");
		JSON.put( "email", "Dummy11@martway.com");

		request.body(JSON.toString()); // Create Body

		Response resp = request.post("http://localhost:3000/employees123"); // POST-  to create new one

		int code = resp.getStatusCode();

		System.out.println("The Code is :" + code);

	}
	
	public static void ExcerciseJSONDELETE() {
		
		RequestSpecification request = RestAssured.given(); // Request specification means sending the request in this format

		request.header("Content-Type", "application/json"); // Add header
		Response resp = request.delete("http://localhost:3000/employees123/6"); 

		int code = resp.getStatusCode();

		System.out.println("The Code is :" + code);
	
	}
	
	//Method to "POST" into JSON server and verify whether it is correctly Posted
	public static void ExcerciseValidatePostJSON() throws JSONException {
		// Posting into DB - JSON Server
		String Data=null;
		RequestSpecification request = RestAssured.given(); // Request specification means sending the request in this format
		request.header("Content-Type", "application/json"); // Add header
		JSONObject JSON = new JSONObject(); // Create JSON object	
		JSON.put("id", 12); // Everytime you run this method, plz change the id value to 13 or 14 or 15 .... so on
		JSON.put("first_name", "DummyFirst12");
		JSON.put("last_name", "DummyLast12");
		JSON.put( "email", "Dummy12@martway.com");
		request.body(JSON.toString()); // Create Body
		Response resp = request.post("http://localhost:3000/employees123"); // POST-  to create new one
		System.out.println(resp.getStatusCode());
		
		// Whatever Posted, we are fetching to check whether correctly posted 
		String DataV3=null;
		int codeV3=0;
		try {
			Response RespV3=RestAssured.get("http://localhost:3000/employees123/12");	// Change the exact id which given in line 108	
			 codeV3=RespV3.getStatusCode();		
			System.out.println("Status code :"+codeV3);		
			DataV3 = RespV3.asString();
			System.out.println(DataV3);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
		
		JSONObject A = new JSONObject(DataV3);
		A.get("first_name");
		System.out.println(A.get("first_name"));
		
		if (JSON.get("first_name").toString().equalsIgnoreCase(A.get("first_name").toString())) {
			System.out.println("Yes!! correctly Posted in JSON server");
		}else {
			System.out.println("No!! Im wrong, will work again");
		}
	}


}
